import React from 'react'

const PersonalFiles = () => {
  return (
    <div>PersonalFiles</div>
  )
}

export default PersonalFiles