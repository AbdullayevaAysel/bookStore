import Routes from "./common/navigate"

function App() {
  return (
    <>
      <Routes />
    </>
  )
}

export default App
